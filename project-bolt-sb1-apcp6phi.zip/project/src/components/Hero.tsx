import React from 'react';
import { ChefHat, Star, Clock } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg)',
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="mb-8">
          <ChefHat className="w-16 h-16 text-amber-400 mx-auto mb-4" />
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Flavors<span className="text-amber-400">World</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-8 leading-relaxed">
            Experience authentic cuisine from around the globe in one extraordinary location
          </p>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap justify-center gap-8 mb-12">
          <div className="flex items-center space-x-2 text-white">
            <Star className="w-6 h-6 text-amber-400 fill-current" />
            <span className="text-lg font-semibold">4.9 Rating</span>
          </div>
          <div className="flex items-center space-x-2 text-white">
            <Clock className="w-6 h-6 text-amber-400" />
            <span className="text-lg font-semibold">30+ Years</span>
          </div>
          <div className="flex items-center space-x-2 text-white">
            <ChefHat className="w-6 h-6 text-amber-400" />
            <span className="text-lg font-semibold">4 Cuisines</span>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => scrollToSection('#menu')}
            className="bg-amber-600 hover:bg-amber-700 text-white font-bold py-4 px-8 rounded-full text-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            Explore Menu
          </button>
          <button
            onClick={() => scrollToSection('#reservation')}
            className="bg-transparent border-2 border-white hover:bg-white hover:text-gray-900 text-white font-bold py-4 px-8 rounded-full text-lg transition-all duration-300 transform hover:scale-105"
          >
            Reserve Table
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;