import React, { useState } from 'react';
import { X } from 'lucide-react';

const Gallery: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const galleryImages = [
    {
      src: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg',
      alt: 'Elegant dining room',
      category: 'Interior'
    },
    {
      src: 'https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg',
      alt: 'Fresh pizza',
      category: 'Food'
    },
    {
      src: 'https://images.pexels.com/photos/2474661/pexels-photo-2474661.jpeg',
      alt: 'Indian curry',
      category: 'Food'
    },
    {
      src: 'https://images.pexels.com/photos/761963/pexels-photo-761963.jpeg',
      alt: 'Bar area',
      category: 'Interior'
    },
    {
      src: 'https://images.pexels.com/photos/357756/pexels-photo-357756.jpeg',
      alt: 'Fresh sushi',
      category: 'Food'
    },
    {
      src: 'https://images.pexels.com/photos/4958792/pexels-photo-4958792.jpeg',
      alt: 'Mexican tacos',
      category: 'Food'
    },
    {
      src: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg',
      alt: 'Cozy dining',
      category: 'Interior'
    },
    {
      src: 'https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg',
      alt: 'Pasta carbonara',
      category: 'Food'
    },
    {
      src: 'https://images.pexels.com/photos/5949892/pexels-photo-5949892.jpeg',
      alt: 'Mushroom risotto',
      category: 'Food'
    }
  ];

  return (
    <section id="gallery" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Gallery
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Step inside our world of flavors and discover the ambiance that makes every meal memorable.
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image, index) => (
            <div
              key={index}
              className="relative group overflow-hidden rounded-xl shadow-lg cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-xl"
              onClick={() => setSelectedImage(image.src)}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
                <div className="text-white text-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="text-lg font-semibold">{image.alt}</p>
                  <p className="text-sm bg-amber-600 px-3 py-1 rounded-full mt-2 inline-block">
                    {image.category}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal */}
        {selectedImage && (
          <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
            <div className="relative max-w-4xl max-h-full">
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute -top-12 right-0 text-white hover:text-amber-400 transition-colors duration-200"
              >
                <X className="w-8 h-8" />
              </button>
              <img
                src={selectedImage}
                alt="Gallery image"
                className="max-w-full max-h-full object-contain rounded-lg"
              />
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Gallery;