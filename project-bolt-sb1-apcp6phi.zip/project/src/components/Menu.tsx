import React, { useState } from 'react';
import { Star, Flame, Leaf } from 'lucide-react';
import { cuisines } from '../data/menuData';
import { Cuisine } from '../types';

const Menu: React.FC = () => {
  const [selectedCuisine, setSelectedCuisine] = useState<string>('italian');

  const currentCuisine = cuisines.find(c => c.id === selectedCuisine) || cuisines[0];

  const getSpicyIcon = (level?: number) => {
    if (!level) return null;
    return (
      <div className="flex items-center space-x-1">
        {[...Array(level)].map((_, i) => (
          <Flame key={i} className="w-4 h-4 text-red-500 fill-current" />
        ))}
      </div>
    );
  };

  return (
    <section id="menu" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our International Menu
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover authentic flavors from around the world, crafted by our expert chefs using traditional recipes and the finest ingredients.
          </p>
        </div>

        {/* Cuisine Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {cuisines.map((cuisine) => (
            <button
              key={cuisine.id}
              onClick={() => setSelectedCuisine(cuisine.id)}
              className={`flex items-center space-x-3 px-6 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 ${
                selectedCuisine === cuisine.id
                  ? 'bg-amber-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-amber-100 border border-gray-200'
              }`}
            >
              <span className="text-2xl">{cuisine.flag}</span>
              <span>{cuisine.name}</span>
            </button>
          ))}
        </div>

        {/* Current Cuisine Info */}
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-2">
            {currentCuisine.flag} {currentCuisine.name} Cuisine
          </h3>
          <p className="text-lg text-gray-600">{currentCuisine.description}</p>
        </div>

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {currentCuisine.items.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                />
                <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                  {item.isPopular && (
                    <span className="bg-amber-500 text-white px-2 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
                      <Star className="w-3 h-3 fill-current" />
                      <span>Popular</span>
                    </span>
                  )}
                  {item.isVegetarian && (
                    <span className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
                      <Leaf className="w-3 h-3 fill-current" />
                      <span>Veg</span>
                    </span>
                  )}
                </div>
                <div className="absolute top-4 right-4">
                  <span className="bg-black bg-opacity-75 text-white px-3 py-1 rounded-full font-bold text-lg">
                    ${item.price}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="text-xl font-bold text-gray-900">{item.name}</h4>
                  {getSpicyIcon(item.spicyLevel)}
                </div>
                <p className="text-gray-600 mb-4 leading-relaxed">{item.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-amber-600 bg-amber-100 px-3 py-1 rounded-full">
                    {item.category}
                  </span>
                  <button className="bg-amber-600 hover:bg-amber-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200">
                    Order Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Menu;