import React from 'react';
import { Users, Award, Heart, Globe } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    {
      icon: Globe,
      title: 'Global Cuisine',
      description: 'Authentic dishes from Italy, India, Japan, and Mexico prepared by native chefs.'
    },
    {
      icon: Award,
      title: 'Award Winning',
      description: 'Recognized for excellence in international cuisine and exceptional service.'
    },
    {
      icon: Heart,
      title: 'Made with Love',
      description: 'Every dish is crafted with passion using the finest, freshest ingredients.'
    },
    {
      icon: Users,
      title: 'Family Tradition',
      description: 'Three generations of culinary expertise bringing families together through food.'
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Our Story
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Founded in 1995, FlavorsWorld began as a dream to bring authentic international cuisine 
              to one extraordinary location. Our founders, Maria and Giuseppe, traveled the world to 
              learn traditional cooking techniques and build relationships with local suppliers.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Today, we're proud to serve dishes that honor the rich culinary traditions of Italy, 
              India, Japan, and Mexico. Each recipe tells a story, and every meal creates memories 
              that last a lifetime.
            </p>

            {/* Features Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="bg-amber-100 p-3 rounded-full">
                    <feature.icon className="w-6 h-6 text-amber-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Images */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <img
                src="https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg"
                alt="Chef preparing food"
                className="w-full h-48 object-cover rounded-xl shadow-lg"
              />
              <img
                src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg"
                alt="Restaurant interior"
                className="w-full h-32 object-cover rounded-xl shadow-lg"
              />
            </div>
            <div className="space-y-4 mt-8">
              <img
                src="https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg"
                alt="Fresh ingredients"
                className="w-full h-32 object-cover rounded-xl shadow-lg"
              />
              <img
                src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg"
                alt="Dining experience"
                className="w-full h-48 object-cover rounded-xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;