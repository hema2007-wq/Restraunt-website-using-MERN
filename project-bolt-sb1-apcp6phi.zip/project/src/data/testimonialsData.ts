import { Testimonial } from '../types';

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    rating: 5,
    comment: 'Absolutely incredible experience! The Italian dishes were authentic and the service was impeccable. The atmosphere is perfect for a romantic dinner.',
    date: '2024-01-15',
    avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg'
  },
  {
    id: '2',
    name: 'Michael Chen',
    rating: 5,
    comment: 'The sushi here is the best I\'ve had outside of Japan. Fresh ingredients and expert preparation. The miso ramen was also outstanding!',
    date: '2024-01-10',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg'
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    rating: 4,
    comment: 'Love the variety of cuisines! The Indian curry was perfectly spiced and the Mexican tacos were delicious. Great place for groups with different tastes.',
    date: '2024-01-08',
    avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg'
  },
  {
    id: '4',
    name: 'David Kumar',
    rating: 5,
    comment: 'The butter chicken reminded me of home! Authentic flavors and generous portions. The staff is knowledgeable about spice levels too.',
    date: '2024-01-05',
    avatar: 'https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg'
  }
];