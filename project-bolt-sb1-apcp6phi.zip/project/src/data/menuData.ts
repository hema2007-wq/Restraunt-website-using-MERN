import { Cuisine } from '../types';

export const cuisines: Cuisine[] = [
  {
    id: 'italian',
    name: 'Italian',
    description: 'Authentic Italian cuisine with fresh ingredients and traditional recipes',
    flag: '🇮🇹',
    items: [
      {
        id: 'margherita',
        name: 'Margherita Pizza',
        description: 'Fresh tomatoes, mozzarella, basil, and olive oil on crispy crust',
        price: 18,
        image: 'https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg',
        category: 'Pizza',
        isVegetarian: true,
        isPopular: true
      },
      {
        id: 'carbonara',
        name: 'Spaghetti Carbonara',
        description: 'Classic Roman pasta with eggs, pancetta, and parmesan',
        price: 22,
        image: 'https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg',
        category: 'Pasta'
      },
      {
        id: 'risotto',
        name: 'Mushroom Risotto',
        description: 'Creamy arborio rice with wild mushrooms and truffle oil',
        price: 26,
        image: 'https://images.pexels.com/photos/5949892/pexels-photo-5949892.jpeg',
        category: 'Rice',
        isVegetarian: true
      }
    ]
  },
  {
    id: 'indian',
    name: 'Indian',
    description: 'Aromatic spices and bold flavors from the subcontinent',
    flag: '🇮🇳',
    items: [
      {
        id: 'butter-chicken',
        name: 'Butter Chicken',
        description: 'Tender chicken in creamy tomato-based curry sauce',
        price: 24,
        image: 'https://images.pexels.com/photos/2474661/pexels-photo-2474661.jpeg',
        category: 'Curry',
        spicyLevel: 2,
        isPopular: true
      },
      {
        id: 'biryani',
        name: 'Chicken Biryani',
        description: 'Fragrant basmati rice with spiced chicken and saffron',
        price: 28,
        image: 'https://images.pexels.com/photos/12737657/pexels-photo-12737657.jpeg',
        category: 'Rice',
        spicyLevel: 3
      },
      {
        id: 'dal-tadka',
        name: 'Dal Tadka',
        description: 'Yellow lentils tempered with cumin and garlic',
        price: 16,
        image: 'https://images.pexels.com/photos/5560763/pexels-photo-5560763.jpeg',
        category: 'Vegetarian',
        isVegetarian: true,
        spicyLevel: 1
      }
    ]
  },
  {
    id: 'japanese',
    name: 'Japanese',
    description: 'Fresh sushi and traditional Japanese dishes',
    flag: '🇯🇵',
    items: [
      {
        id: 'salmon-sashimi',
        name: 'Salmon Sashimi',
        description: 'Fresh Norwegian salmon, expertly sliced',
        price: 32,
        image: 'https://images.pexels.com/photos/357756/pexels-photo-357756.jpeg',
        category: 'Sashimi',
        isPopular: true
      },
      {
        id: 'chicken-teriyaki',
        name: 'Chicken Teriyaki',
        description: 'Grilled chicken with sweet teriyaki glaze and steamed rice',
        price: 26,
        image: 'https://images.pexels.com/photos/5474640/pexels-photo-5474640.jpeg',
        category: 'Grilled'
      },
      {
        id: 'miso-ramen',
        name: 'Miso Ramen',
        description: 'Rich miso broth with noodles, pork, and vegetables',
        price: 20,
        image: 'https://images.pexels.com/photos/884600/pexels-photo-884600.jpeg',
        category: 'Noodles'
      }
    ]
  },
  {
    id: 'mexican',
    name: 'Mexican',
    description: 'Vibrant flavors and fresh ingredients from Mexico',
    flag: '🇲🇽',
    items: [
      {
        id: 'tacos-al-pastor',
        name: 'Tacos Al Pastor',
        description: 'Marinated pork with pineapple, onions, and cilantro',
        price: 18,
        image: 'https://images.pexels.com/photos/4958792/pexels-photo-4958792.jpeg',
        category: 'Tacos',
        spicyLevel: 2,
        isPopular: true
      },
      {
        id: 'guacamole',
        name: 'Fresh Guacamole',
        description: 'Avocados, lime, onions, tomatoes, and cilantro with tortilla chips',
        price: 14,
        image: 'https://images.pexels.com/photos/2092507/pexels-photo-2092507.jpeg',
        category: 'Appetizer',
        isVegetarian: true
      },
      {
        id: 'enchiladas',
        name: 'Chicken Enchiladas',
        description: 'Corn tortillas filled with chicken, topped with red sauce and cheese',
        price: 22,
        image: 'https://images.pexels.com/photos/7218637/pexels-photo-7218637.jpeg',
        category: 'Main',
        spicyLevel: 2
      }
    ]
  }
];